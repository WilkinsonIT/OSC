﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSC
{
    internal class APIPayload
    {
        public string Name;
        public string ShareCode;
        public string APIKey;
        public string P_op;
        public string P_dur;
        public string P_int;

    }
}
