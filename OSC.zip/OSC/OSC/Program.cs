﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using SharpOSC;
using System.Threading;


namespace OSC
{
    internal static class Program
    {
        public static int P_dur;
        public static int P_int;
        public static int P_op;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]

        public static void ExtractArg()
        {

        }

        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());

            HandleOscPacket callback = delegate (OscPacket packet)
            {
                var messageReceived = (OscMessage)packet;
                
                Console.WriteLine("Received a message!");
                //FIX THE ADDRESSES
                if(string.Compare(messageReceived.Address,"avatar/P_dur")==0)
                {
                    P_dur = Int32.Parse(messageReceived.Arguments[0].ToString());
                }
                else if(string.Compare(messageReceived.Address, "avatar/P_int") == 0)
                {
                    P_int = Int32.Parse(messageReceived.Arguments[0].ToString());
                }
                else if(string.Compare(messageReceived.Address, "avatar/P_int") == 0)
                {
                    P_op = Int32.Parse(messageReceived.Arguments[0].ToString());
                }
            };

            var listener = new UDPListener(55555, callback);

            


        }
    }
}
